# Sentinel OSS

Sentinel OSS is a student-friendly Linux security and infrastructure monitoring project.
It is designed to help cybersecurity students learn system monitoring, log analysis, secure authentication, REST API development, and database integration.

## Project Goals

- Learn Linux system monitoring and Linux internals.
- Learn log analysis and security event detection.
- Learn secure authentication and session handling.
- Learn REST API development with C++.
- Learn SQLite database integration.
- Learn VPS deployment and systemd service setup.
- Learn defensive cybersecurity practices.

## What this project includes

- A simple C++17 backend using SQLite for storage.
- A REST-style API server for metrics and events.
- A small frontend dashboard for visualization.
- Incremental modules with clear learning notes and documentation.

## Module 1: DB Layer

This first module builds a small SQLite wrapper and a test executable.
The goal is to understand how to safely open and query a database.

## Learning Notes

- `db/db.h` defines a small wrapper around SQLite.
- `db/db.cpp` initializes the database using `sqlite3_open_v2`.
- The test executable uses an in-memory SQLite database to verify functionality.

## Build instructions

For Oracle Linux 9, see `docs/INSTALL.md` for exact setup commands.

## Running the host/API server

Once built, run the server from the workspace root:

```bash
./build/sentinel_server
```

The server listens on port `8080` by default. Then open the service in a browser:

```bash
http://<your-server-ip>:8080/
```

***
