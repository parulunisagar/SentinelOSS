# Sentinel OSS

[![License](https://img.shields.io/badge/license-MIT-blue.svg)](LICENSE) [![Build](https://img.shields.io/badge/build-passing-brightgreen.svg)](#) [![Release](https://img.shields.io/badge/release-0.3.0-blueviolet.svg)](#)

Sentinel OSS is a polished open-source Linux monitoring and security dashboard built in C++17. It delivers system metrics, real-time alerts, and an Oracle Cloud-compatible deployment path.

## Highlights

- Modern dark theme dashboard with responsive design and glassmorphism cards.
- Live updates every 2 seconds using a lightweight browser dashboard.
- Real-time CPU, RAM, disk, network, uptime, and health score display.
- Chart.js graphs for CPU, memory, and network traffic.
- New REST API endpoints for metrics, health, alerts, system, and network data.
- Oracle Linux 9 compatible and deployable as a systemd-managed service.

## Live Features

- `/` — polished dashboard UI
- `/api/metrics` — full system metrics JSON
- `/api/health` — calculated health score and status
- `/api/alerts` — active system alerts
- `/api/system` — CPU, memory, uptime, and disk details
- `/api/network` — network statistics only

## Screenshots

- Dashboard overview with health indicators and alert cards
- CPU, RAM, and network traffic charts
- Dark glassmorphism dashboard with mobile responsiveness

> Add actual screenshots in `docs/screenshots/` when available.

## Quick Start

```bash
cd /path/to/project
mkdir -p build && cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
cmake --build . --target sentinel_server -j$(nproc)
./src/sentinel_server
```

Then open:

```bash
http://<your-server-ip>:8080/
```

## Deployment

For Oracle Cloud Linux 9, follow `docs/INSTALL.md` and `docs/DEPLOYMENT.md` for package setup, firewall rules, OCI network rules, and systemd service configuration.

## Contributing

See `CONTRIBUTING.md`, `SECURITY.md`, and `CODE_OF_CONDUCT.md` for project contribution guidelines, vulnerability reporting, and community standards.
