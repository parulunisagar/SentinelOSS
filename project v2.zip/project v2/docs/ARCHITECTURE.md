# Architecture Notes

Sentinel OSS is designed as a lightweight C++ monitoring platform with a simple service structure and a browser dashboard for modern observability.

## Design Principles

- Keep the server minimal and portable with C++17.
- Serve a polished UI and JSON endpoint from a single process.
- Maintain compatibility with existing metrics endpoints.
- Enable fast feedback loops through live dashboard refresh.

## Component Overview

- `src/db/` contains the SQLite wrapper and schema support.
- `src/collector/` collects Linux host metrics from `/proc`.
- `src/server.cpp` handles HTTP routing, dashboard delivery, and JSON endpoints.
- `src/main.cpp` launches the server on port `8080`.

## Runtime behavior

- The dashboard at `/` loads Chart.js and refreshes metrics every 2 seconds.
- `/api/metrics` returns the full metric payload.
- `/api/health` computes a health score from CPU, memory, and disk utilization.
- `/api/alerts` produces active alert cards for high resource usage.
- `/api/system` and `/api/network` provide dedicated JSON views.

## Deployment targets

- Oracle Linux 9 is the supported target for production deployment.
- The service is friendly for systemd management and can be run as a non-root user.
