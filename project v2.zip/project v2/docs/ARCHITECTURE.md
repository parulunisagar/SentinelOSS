# Architecture Notes

Sentinel OSS is intentionally small and easy to understand. It is built as a learning project for cybersecurity students.

## Design Principles

- Keep the backend simple: one C++ service, one SQLite database, one REST API.
- Favor clarity over abstraction.
- Use plain data structures and small modules.
- Document why each feature exists.

## Component Overview

- `src/db/` contains the database wrapper and schema support.
- `db/schema.sql` defines the tables needed for monitoring and security events.
- `src/db_test.cpp` proves the DB wrapper works using an in-memory database.

## Why these tables exist

- `users` and `sessions`: needed to learn secure authentication and session management.
- `metrics`, `processes`, `disks`, `network_stats`: teach system monitoring and time-series storage.
- `events` and `alerts`: teach security event collection and alerting.
- `services`: help track whether critical Linux services are up or down.
- `audit_logs`: collect raw log data for defensive security analysis.
- `rate_limits`: learn how to protect APIs from abuse.

## Learning path

1. Start with the DB layer and schema.
2. Add collection logic for host metrics.
3. Add event parsing and security detection.
4. Build the REST API and frontend.
5. Deploy to a VPS and learn how Linux server services are managed.
