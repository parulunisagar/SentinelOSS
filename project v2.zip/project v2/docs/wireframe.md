# Sentinel OSS — Frontend Wireframe

Pages:

- Login
  - Username, Password
  - Remember me checkbox (optional)

- Dashboard (main)
  - Top navbar: logo, system name, current user dropdown, settings, logout
  - Left sidebar: Overview, Metrics, Processes, Network, Events, Alerts, Services, Settings

  - Main area (responsive grid):
    - Row 1: Live Overview cards
      - CPU: current %, sparkline
      - Memory: used/total, %
      - Disk: used % (root), alert indicator
      - Network: current rx/tx

    - Row 2: Charts
      - Large chart: CPU history (time-series)
      - Large chart: Memory history

    - Row 3: Event timeline (left) and Alerts list (right)
      - Event timeline shows icons for event types; clicking shows details pane
      - Alerts list allows ack, mute

Interactions:
- Poll `/api/v1/metrics/{type}/latest` every 5s for live cards.
- Poll `/api/v1/metrics?type=cpu&start=...&end=...` when viewing charts, with adjustable range.
- Poll `/api/v1/events?since=...` every 5s for timeline updates.
- Actions (ack alert, login) post JSON to API with `X-Auth-Token` header.

Implementation notes:
- Use vanilla JS, Fetch API, and HTML5 Canvas for charts (no external libraries).
- Keep assets static; server serves `/` and static files under `/web/`.

Accessibility:
- Use semantic HTML, ARIA labels on interactive controls, keyboard navigation for timeline.
