# Installation Guide

This guide shows how to set up the project dependencies, build Sentinel OSS, and run the monitoring server on Oracle Linux 9.

## Prerequisites

- Oracle Linux 9 VPS with sudo privileges.
- Network access to install packages.

## Install build tools and dependencies

```bash
sudo dnf update -y
sudo dnf groupinstall -y "Development Tools"
sudo dnf install -y cmake pkgconfig sqlite-devel sqlite openssl-devel git
```

## Build the project

```bash
cd /path/to/sentinel-oss
mkdir -p build && cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
cmake --build . --target sentinel_server -j$(nproc)
```

## Run the service manually

```bash
cd /path/to/sentinel-oss/build
./src/sentinel_server
```

Then visit:

```bash
http://<your-server-ip>:8080/
```

## Run as a background service using systemd

Create `/etc/systemd/system/sentinel.service` and use the following configuration:

```ini
[Unit]
Description=Sentinel OSS HTTP server
After=network.target

[Service]
Type=simple
User=opc
WorkingDirectory=/home/opc/SentinelOSS/project v2/build
ExecStart=/usr/local/bin/sentinel_server
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Then start it:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now sentinel.service
sudo systemctl status sentinel.service
```

## Notes

- Ensure the binary path matches your project location.
- Use the Oracle Cloud networking guide in `docs/DEPLOYMENT.md` to open port 8080 safely.
