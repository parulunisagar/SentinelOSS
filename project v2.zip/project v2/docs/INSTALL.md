# Installation Guide

This guide shows how to set up the project dependencies and build Module 1 on Oracle Linux 9.

## Prerequisites

- Oracle Linux 9 VPS with sudo privileges.
- Network access to install packages.

## Install build tools and dependencies

```bash
sudo dnf update -y
sudo dnf groupinstall -y "Development Tools"
sudo dnf install -y cmake pkgconfig sqlite-devel sqlite openssl-devel git
```

## Build the DB module

```bash
cd /path/to/sentinel-oss
mkdir -p build && cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
cmake --build . --target sentinel_db_test -j$(nproc)
```

## Run the DB test

```bash
./src/sentinel_db_test || ./sentinel_db_test
```

## Verify SQLite schema load

```bash
sqlite3 /var/lib/sentinel/sentinel.db < db/schema.sql
sqlite3 /var/lib/sentinel/sentinel.db "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"
```

## Common troubleshooting

- If CMake fails to find SQLite, confirm `sqlite-devel` is installed.
- If the build fails, review the first compiler error and address any missing headers or libraries.

***
