# Deployment Notes

This file explains the high-level deployment path for Sentinel OSS.

## Overview

The project is designed to run on a Linux VPS, such as Oracle Linux 9. In later modules, the service will be deployed as a systemd unit or Docker container.

## Student learning goals

- Learn how to package a C++ service for Linux.
- Learn how to manage long-running services with systemd.
- Learn how to use containerization for repeatable environment setup.

## Current status

At Module 1, we only have a DB layer and no running service yet. Once the server module is built, deployment notes will include:

- required OS packages
- file locations for the SQLite database
- recommended runtime user and permissions
- systemd service file example
- Dockerfile and docker-compose examples
