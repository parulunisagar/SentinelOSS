# Deployment Notes

Sentinel OSS is optimized for deployment on Oracle Linux 9 and is container-friendly while remaining lightweight enough for a standard VPS.

## Oracle Linux 9 deployment

1. Build the project on the instance.
2. Open port `8080` in the Oracle Cloud network rules and host firewall.
3. Run the server manually or use the systemd service.

## Recommended runtime setup

- Run the service as a non-root user such as `opc`.
- Keep the code in a versioned project directory.
- Use systemd to manage uptime, restarts, and logging.

## Systemd service example

Create `/etc/systemd/system/sentinel.service`:

```ini
[Unit]
Description=Sentinel OSS HTTP server
After=network.target

[Service]
Type=simple
User=opc
WorkingDirectory=/home/opc/SentinelOSS/project v2/build
ExecStart=/usr/local/bin/sentinel_server
Restart=on-failure
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Then apply:

```bash
sudo systemctl daemon-reload
sudo systemctl enable --now sentinel.service
```

## Oracle Cloud network rules

- Add a security list or NSG ingress rule for TCP port `8080`.
- Set source CIDR to your trusted IP range or `0.0.0.0/0` for public access.
- Verify the subnet route table has an Internet Gateway if public access is required.

## Firewall rules on the VM

If using `firewalld`:

```bash
sudo firewall-cmd --permanent --add-port=8080/tcp
sudo firewall-cmd --reload
```

If using `iptables`:

```bash
sudo iptables -I INPUT -p tcp --dport 8080 -j ACCEPT
sudo service iptables save
```

## Health checks

- Browser: `http://<public-ip>:8080/`
- Metrics endpoint: `http://<public-ip>:8080/api/metrics`
- Health endpoint: `http://<public-ip>:8080/api/health`
- Alerts endpoint: `http://<public-ip>:8080/api/alerts`
