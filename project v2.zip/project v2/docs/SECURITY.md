# Security Notes

This project is a learning tool for defensive security, so the first modules focus on safe design choices.

## Student security goals

- Understand why password hashing matters.
- Learn how database integrity helps prevent bad state.
- Learn why rate limiting protects APIs.
- Learn what security data is useful to collect.

## Current security considerations

- The DB wrapper enables foreign keys for data integrity.
- WAL mode is enabled to reduce corruption risk.
- Future modules will add:
  - hashed passwords
  - session tokens
  - input validation
  - rate limiting
  - secure TLS transport
