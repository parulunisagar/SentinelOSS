# Contributing to Sentinel OSS

This project is built as a learning lab. Contributions should stay small and focused so each change is easy to understand.

## How to contribute

1. Open an issue with the feature idea or bug.
2. Make a branch for one module or fix.
3. Keep your changes small and well-commented.
4. Add notes in `DEVELOPMENT_NOTES.md` for anything important.

## Student-friendly rules

- Prefer clear code over clever code.
- Explain security decisions in comments.
- Add learning notes when you add a feature.
- Avoid large refactors until the project is more mature.
