# Sentinel OSS — API Specification (v1)

Base URL: `/api/v1`

Authentication:
- All protected endpoints require `X-Auth-Token: <session-token>` header or `Authorization: Bearer <session-token>`.
- Login returns a session token.
- Rate limited: clients should handle `429 Too Many Requests`.

Content-Type: `application/json` for JSON bodies; responses are JSON.

Endpoints:

- POST `/api/v1/login`
  - Description: Authenticate user and create session.
  - Body: `{ "username": "user", "password": "pass" }`
  - Response: `{ "token": "...", "expires_at": 1670000000 }` (200)
  - Errors: 400 (validation), 401 (invalid creds), 429 (rate limit)

- POST `/api/v1/logout`
  - Auth required.
  - Body: none
  - Response: `{ "ok": true }`

- GET `/api/v1/metrics?type=cpu&start=...&end=...&limit=...`
  - Query params: `type` required (cpu,memory,disk,network,process), optional `start` and `end` (epoch seconds), `limit` (int)
  - Response: `{ "metric_type":"cpu", "samples": [ {"timestamp":..., "value":..., "meta": {...} } ] }`

- GET `/api/v1/metrics/{type}/latest`
  - Returns latest sample for metric `type`.

- GET `/api/v1/events?limit=50&since=...&type=...`
  - Returns list of security and system events.
  - Response: `{ "events": [ {"id":...,"timestamp":...,"type":"failed_login","ip":"1.2.3.4","message":"...","meta":{}} ] }`

- GET `/api/v1/alerts`
  - Returns active alerts; supports `resolved=0|1` filter.

- POST `/api/v1/alerts/{id}/ack`
  - Auth required. Acknowledge alert.

- GET `/api/v1/services`
  - Returns tracked services and current status.

- POST `/api/v1/users` (admin)
  - Create a user. Body: `{ "username":"...", "password":"...", "is_admin":0 }`

- GET `/api/v1/users` (admin)
  - List users. Never return password hashes.

Security and Rate Limits:
- All inputs validated server-side; string lengths enforced.
- Authentication tokens are random, stored server-side with expiry.
- Passwords hashed with PBKDF2-HMAC-SHA256 (configurable iterations); salts stored per-user.
- Rate limiter enforces per-IP per-endpoint windows (configurable).

Errors:
- Standard JSON error format: `{ "error": "message", "code": 123 }`

Notes:
- TLS is required in production; server can be configured with cert/key.
- Pagination via `limit` and `since` or `start`/`end`.
