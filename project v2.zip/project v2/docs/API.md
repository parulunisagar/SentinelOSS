# Sentinel OSS — Public API

Sentinel OSS exposes a small set of unauthenticated monitoring endpoints for dashboard rendering and health checks.

## Base URL

- `/`
- `/api/metrics`
- `/api/health`
- `/api/alerts`
- `/api/system`
- `/api/network`

## Endpoints

### GET `/api/metrics`
Returns the current full host metrics payload.

Response example:

```json
{
  "cpu": { "usage_percent": 12.8 },
  "memory": { "used_percent": 43.1 },
  "uptime_seconds": 12345,
  "disks": [ ... ],
  "network": [ ... ]
}
```

### GET `/api/health`
Returns a simple host health score and status.

Response example:

```json
{
  "health_score": 92,
  "status": "Excellent",
  "recommended_action": "System is healthy."
}
```

### GET `/api/alerts`
Returns active alert cards based on the latest metrics.

Response example:

```json
{
  "alerts": [
    { "title": "High CPU Usage", "message": "CPU usage exceeded 80%." }
  ]
}
```

### GET `/api/system`
Returns system metrics excluding network data.

### GET `/api/network`
Returns network statistics only.

## Compatibility

- `/api/metrics` remains fully compatible with existing monitoring clients.
- New endpoints provide separate health, alert, and network views for dashboard support.

## Notes

- This server currently serves public metrics without authentication.
- In production, add TLS and authentication to protect the service.
