# Static Code Review — Module 1 (DB Layer)

Date: 2026-06-02

Reviewed files:
- `CMakeLists.txt`
- `src/CMakeLists.txt`
- `src/db/db.h`
- `src/db/db.cpp`
- `src/db_test.cpp`
- `db/schema.sql`

Findings
--------

1) CMake / Build
- Top-level `CMakeLists.txt` calls `find_package(SQLite3 REQUIRED)` and then `add_subdirectory(src)`. The `src/CMakeLists.txt` links to `SQLite::SQLite3` imported target. On some CMake installations / FindSQLite3 implementations the imported target `SQLite::SQLite3` may not be provided. This will produce a configure error:
  - "Could not find a configuration file for package "SQLite3""
  - Or: target `SQLite::SQLite3` not found.

  Recommendation: either verify CMake provides the `SQLite::SQLite3` target on the target machine, or change linking to use `${SQLite3_LIBRARIES}` and `${SQLite3_INCLUDE_DIRS}` as fallbacks. Example safe pattern:

  ```cmake
  find_package(SQLite3 REQUIRED)
  if(TARGET SQLite::SQLite3)
    set(SQLITE_LIB target SQLite::SQLite3)
  else()
    set(SQLITE_LIB ${SQLite3_LIBRARIES})
    include_directories(${SQLite3_INCLUDE_DIRS})
  endif()
  target_link_libraries(sentinel_db PUBLIC ${SQLITE_LIB})
  ```

2) Missing / questionable includes in sources
- `src/db/db.cpp` uses `std::move` but does not explicitly include `<utility>`. Standard headers included (`<vector>`, `<map>`, etc.) may pull it transitively on many platforms, but to be strict and portable add `#include <utility>` to `db.cpp` or `db.h` where `std::move` is used.
- `src/db/db.cpp` includes `<iostream>` though it does not use it; harmless but can be removed.

3) Missing libraries / packages
- Build requires:
  - `cmake` (>= 3.16 recommended)
  - A C++17-capable compiler (`gcc` >= 7, but prefer `gcc` >= 9 on Oracle Linux 9)
  - `sqlite-devel` (development headers and libsqlite3)
  - `openssl-devel` (needed later for TLS & crypto; not required for DB test but required by project)
  - `pkgconfig` (recommended for CMake module detection)

4) SQLite API usage
- Usage of the C API is correct in general:
  - `sqlite3_open_v2` with flags `SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX` is acceptable for a multi-threaded process.
  - Setting `sqlite3_busy_timeout` is appropriate.
  - `sqlite3_exec` with an error message pointer is handled and `sqlite3_free` called when non-null.
  - `sqlite3_errstr(rc)` for an error string when `errmsg` is null is acceptable.

  Minor notes:
  - `sqlite3_errstr` was added in SQLite 3.7.15 and should be available on modern SQLite releases. If the target system has an older SQLite, fallback to `sqlite3_errmsg(db_)` may be necessary (requires a valid `db_`).
  - The row callback assumes textual columns; `argv[i]` may be null and is guarded. Binary data or large blobs would be returned as strings; that is acceptable for this wrapper but callers should be aware.

5) Oracle Linux 9 compatibility
- Code is POSIX/C++ and uses SQLite C API — compatible with Oracle Linux 9.
- Oracle Linux 9 ships modern GCC (9/11) and glibc; C++17 features used here (no newer features) are supported.
- Ensure `sqlite-devel` provided by distro is installed.

6) C++17 compatibility
- Uses `noexcept`, `std::string`, `std::map`, `std::vector`, `std::move` — all C++17-compatible.
- No use of C++20 features.

7) Other remarks
- `target_include_directories(sentinel_db PUBLIC ${CMAKE_CURRENT_SOURCE_DIR})` in `src/CMakeLists.txt` exposes the entire `src` directory as an include root. It's acceptable, but consider exposing `src` or `src/` and including headers as `db/db.h`. Optionally set `target_include_directories(... PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/)` explicitly.
- The `db/schema.sql` contains `PRAGMA` statements at the top; when loaded via `executeScriptFromFile`, SQLite will execute them — good for migrations.

Recommended change list (minimal, to maximize portability):
- Add `#include <utility>` to `src/db/db.cpp` to ensure `std::move` is declared.
- Remove unused `#include <iostream>` from `src/db/db.cpp`.
- Update `src/CMakeLists.txt` to robustly link SQLite, guarding for availability of `SQLite::SQLite3` imported target.
- Consider adding a small `FindSQLite3.cmake` fallback or rely on `pkg-config` if `find_package` fails.

Suggested quick CMake patch (example snippet to replace the link lines in `src/CMakeLists.txt`):

```cmake
find_package(SQLite3 REQUIRED)
if(TARGET SQLite::SQLite3)
  set(SQLITE_LIB SQLite::SQLite3)
else()
  set(SQLITE_LIB ${SQLite3_LIBRARIES})
  target_include_directories(sentinel_db PUBLIC ${SQLite3_INCLUDE_DIRS})
endif()
target_link_libraries(sentinel_db PUBLIC ${SQLITE_LIB})

target_link_libraries(sentinel_db_test PRIVATE sentinel_db ${SQLITE_LIB})
```

Exact Oracle Linux 9 commands to install dependencies and build Module 1
--------------------------------------------------------------------

Run the following as a user with `sudo` privileges on an Oracle Linux 9 VPS.

1) Install build tools and required dev packages:

```bash
sudo dnf groupinstall -y "Development Tools"
sudo dnf install -y cmake pkgconfig sqlite-devel openssl-devel git
```

2) Confirm compiler and tools versions (example):

```bash
gcc --version
cmake --version
```

3) Build the DB module and run the test:

```bash
cd /path/to/sentinel-oss   # replace with project root
mkdir -p build && cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
cmake --build . --target sentinel_db_test -j$(nproc)
# Run the test executable (location may be build/src/sentinel_db_test)
./src/sentinel_db_test
```

If `cmake` configuration fails complaining about `SQLite::SQLite3` target, modify `src/CMakeLists.txt` to link via `${SQLite3_LIBRARIES}` and `${SQLite3_INCLUDE_DIRS}` per the snippet above, then re-run `cmake`.

Verification steps
- The test should print two rows:
  - `row: id=1 name=alice`
  - `row: id=2 name=bob`

Closure
-------

Module 1 is small and self-contained. The code is mostly correct and portable with the minor include and CMake portability issues noted above. After installing system packages and (if needed) adjusting `src/CMakeLists.txt` to link SQLite properly, the DB test should compile and run successfully on Oracle Linux 9.
