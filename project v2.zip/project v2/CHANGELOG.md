# Changelog

## 0.1.0 - Module 1

- Added initial SQLite database wrapper and DB module.
- Added SQL schema for users, sessions, metrics, events, alerts, services, and rate limiting.
- Added a simple DB test executable to verify in-memory database operations.
- Added student-focused documentation files and learning notes.
- Updated build configuration for SQLite portability.
