# Changelog

## 0.1.0 - Module 1

- Added initial SQLite database wrapper and DB module.
- Added SQL schema for users, sessions, metrics, events, alerts, services, and rate limiting.
- Added a simple DB test executable to verify in-memory database operations.
- Added student-focused documentation files and learning notes.
- Updated build configuration for SQLite portability.

## 0.2.0 - Module 2

- Added collector engine for Linux system metrics.
- Implemented CPU, memory, disk, network, and uptime monitoring.
- Added collector test executable for compile-time validation.
