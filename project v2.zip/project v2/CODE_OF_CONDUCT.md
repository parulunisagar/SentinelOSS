# Code of Conduct

This project follows a standard open-source code of conduct.

## Our standards

- Be respectful and inclusive.
- Use positive language and assume good intent.
- Do not tolerate harassment or abusive behavior.

## Reporting

If you experience or witness behavior that violates this code of conduct, please contact the maintainers or open an issue.

## Consequences

Maintainers may remove content or contributions that violate these guidelines.
