-- Sentinel OSS SQLite schema
PRAGMA foreign_keys = ON;
PRAGMA journal_mode = WAL;

-- Users table: store admin/users
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash BLOB NOT NULL,
    salt BLOB NOT NULL,
    is_admin INTEGER NOT NULL DEFAULT 0,
    created_at INTEGER NOT NULL -- unix epoch
);

-- Sessions for authentication
CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token TEXT NOT NULL UNIQUE,
    expires_at INTEGER NOT NULL,
    created_at INTEGER NOT NULL
);

-- General time-series metrics table (normalized for flexibility)
CREATE TABLE IF NOT EXISTS metrics (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    metric_type TEXT NOT NULL, -- cpu, memory, disk, network, process
    timestamp INTEGER NOT NULL,
    value REAL NOT NULL,
    meta TEXT -- JSON blob for extra metadata
);
CREATE INDEX IF NOT EXISTS idx_metrics_type_time ON metrics(metric_type, timestamp);

-- Process snapshots (sampled process state)
CREATE TABLE IF NOT EXISTS processes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp INTEGER NOT NULL,
    pid INTEGER NOT NULL,
    name TEXT NOT NULL,
    cpu_percent REAL,
    mem_bytes INTEGER,
    cmdline TEXT
);
CREATE INDEX IF NOT EXISTS idx_processes_time ON processes(timestamp);

-- Disk statistics
CREATE TABLE IF NOT EXISTS disks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp INTEGER NOT NULL,
    mountpoint TEXT NOT NULL,
    total_bytes INTEGER,
    used_bytes INTEGER,
    avail_bytes INTEGER,
    used_percent REAL
);
CREATE INDEX IF NOT EXISTS idx_disks_time ON disks(timestamp);

-- Network statistics
CREATE TABLE IF NOT EXISTS network_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp INTEGER NOT NULL,
    iface TEXT NOT NULL,
    rx_bytes INTEGER,
    tx_bytes INTEGER,
    rx_errors INTEGER,
    tx_errors INTEGER
);
CREATE INDEX IF NOT EXISTS idx_network_time ON network_stats(timestamp);

-- Events (security events, log-derived events)
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp INTEGER NOT NULL,
    event_type TEXT NOT NULL,
    source TEXT,
    message TEXT,
    ip TEXT,
    meta TEXT -- JSON for structured data
);
CREATE INDEX IF NOT EXISTS idx_events_time ON events(timestamp);

-- Alerts
CREATE TABLE IF NOT EXISTS alerts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp INTEGER NOT NULL,
    alert_type TEXT NOT NULL,
    severity TEXT NOT NULL,
    resolved INTEGER NOT NULL DEFAULT 0,
    resolved_at INTEGER,
    details TEXT -- JSON
);
CREATE INDEX IF NOT EXISTS idx_alerts_time ON alerts(timestamp);

-- Services status tracking
CREATE TABLE IF NOT EXISTS services (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    service_name TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL,
    last_checked INTEGER NOT NULL,
    details TEXT
);

-- Audit logs raw storage
CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp INTEGER NOT NULL,
    source TEXT,
    raw TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_time ON audit_logs(timestamp);

-- Rate limiting state
CREATE TABLE IF NOT EXISTS rate_limits (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ip TEXT NOT NULL,
    endpoint TEXT NOT NULL,
    window_start INTEGER NOT NULL,
    count INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_rate_ip_endpoint ON rate_limits(ip, endpoint);
