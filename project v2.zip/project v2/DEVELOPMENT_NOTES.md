# Development Notes

## Module 1: Database Layer

### Purpose
This module is a minimal starting point for Sentinel OSS. It creates a wrapper around SQLite and demonstrates how a security tool can persist measurements, events, and authentication state.

### What I learned
- Opening SQLite with `sqlite3_open_v2` gives control over flags such as `SQLITE_OPEN_FULLMUTEX`.
- Using PRAGMA settings can improve reliability and support foreign key enforcement.
- A simple callback-based query wrapper is enough for learning, even though production systems may use a more advanced ORM or query builder.

### Security notes
- The database is opened in read-write mode with a timeout to avoid transient failures.
- Foreign keys are enabled to prevent orphaned rows in related tables.
- WAL mode improves concurrent access and is a good fit for lightweight monitoring tools.

### Troubleshooting
- If CMake cannot find SQLite, install `sqlite-devel` and ensure the include/lib paths are available.
- If `SQLite::SQLite3` target is missing, the `src/CMakeLists.txt` fallback uses `${SQLite3_LIBRARIES}`.

### Future improvements
- Add schema versioning and migration support.
- Add prepared statement support to avoid SQL injection in later modules.
- Add a proper data access layer for typed metric and event entities.
