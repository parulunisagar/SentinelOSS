#include "collector/collector.h"

#include <array>
#include <cctype>
#include <cstring>
#include <fstream>
#include <sstream>
#include <sys/statvfs.h>
#include <unistd.h>

namespace sentinel {

static bool parseKeyValue(const std::string &line, std::string &key, std::string &value) {
    std::istringstream iss(line);
    if (!(iss >> key >> value)) {
        return false;
    }
    return true;
}

bool Collector::collect(SystemMetrics &out, std::string &error) {
    if (!readCPU(out.cpu, error)) {
        return false;
    }
    if (!readMemory(out.memory, error)) {
        return false;
    }
    if (!readUptime(out.uptime_seconds, error)) {
        return false;
    }
    if (!readDiskStats(out.disks, error)) {
        return false;
    }
    if (!readNetworkStats(out.network, error)) {
        return false;
    }
    return true;
}

bool Collector::readCPU(CPUStat &cpu, std::string &error) {
    std::ifstream in("/proc/stat");
    if (!in) {
        error = "Cannot open /proc/stat";
        return false;
    }

    std::string line;
    if (!std::getline(in, line)) {
        error = "Cannot read /proc/stat";
        return false;
    }

    std::istringstream iss(line);
    std::string label;
    uint64_t user = 0, nice = 0, system = 0, idle = 0, iowait = 0, irq = 0, softirq = 0, steal = 0;
    if (!(iss >> label >> user >> nice >> system >> idle >> iowait >> irq >> softirq >> steal)) {
        error = "Unexpected /proc/stat format";
        return false;
    }

    cpu.idle_seconds = static_cast<double>(idle + iowait);
    cpu.total_seconds = static_cast<double>(user + nice + system + idle + iowait + irq + softirq + steal);
    if (cpu.total_seconds > 0.0) {
        cpu.usage_percent = 100.0 * (cpu.total_seconds - cpu.idle_seconds) / cpu.total_seconds;
    }
    return true;
}

bool Collector::readMemory(MemoryStat &memory, std::string &error) {
    std::ifstream in("/proc/meminfo");
    if (!in) {
        error = "Cannot open /proc/meminfo";
        return false;
    }

    std::string line;
    while (std::getline(in, line)) {
        std::string key, value;
        if (!parseKeyValue(line, key, value)) {
            continue;
        }
        if (key == "MemTotal:") {
            memory.total_kb = std::stoull(value);
        } else if (key == "MemFree:") {
            memory.free_kb = std::stoull(value);
        } else if (key == "MemAvailable:") {
            memory.available_kb = std::stoull(value);
        } else if (key == "Buffers:") {
            memory.buffers_kb = std::stoull(value);
        } else if (key == "Cached:") {
            memory.cached_kb = std::stoull(value);
        }
    }

    if (memory.total_kb == 0) {
        error = "Missing MemTotal in /proc/meminfo";
        return false;
    }

    uint64_t used_kb = memory.total_kb - memory.free_kb;
    memory.used_percent = 100.0 * static_cast<double>(used_kb) / static_cast<double>(memory.total_kb);
    return true;
}

bool Collector::readUptime(double &uptime, std::string &error) {
    std::ifstream in("/proc/uptime");
    if (!in) {
        error = "Cannot open /proc/uptime";
        return false;
    }

    if (!(in >> uptime)) {
        error = "Cannot parse /proc/uptime";
        return false;
    }
    return true;
}

static bool shouldTrackMount(const std::string &fsType) {
    static const std::vector<std::string> ignore = {"tmpfs", "devtmpfs", "proc", "sysfs", "cgroup", "overlay", "squashfs", "autofs", "debugfs", "securityfs", "tracefs"};
    for (auto &entry : ignore) {
        if (fsType == entry) {
            return false;
        }
    }
    return true;
}

bool Collector::readDiskStats(std::vector<DiskStat> &disks, std::string &error) {
    std::ifstream in("/proc/mounts");
    if (!in) {
        error = "Cannot open /proc/mounts";
        return false;
    }

    std::string line;
    while (std::getline(in, line)) {
        std::istringstream iss(line);
        std::string device, mountpoint, fsType, rest;
        if (!(iss >> device >> mountpoint >> fsType)) {
            continue;
        }
        if (!shouldTrackMount(fsType)) {
            continue;
        }

        struct statvfs buf;
        if (statvfs(mountpoint.c_str(), &buf) != 0) {
            continue;
        }

        DiskStat stats;
        stats.mountpoint = mountpoint;
        stats.total_bytes = buf.f_blocks * buf.f_frsize;
        stats.avail_bytes = buf.f_bavail * buf.f_frsize;
        stats.used_bytes = stats.total_bytes - (buf.f_bfree * buf.f_frsize);
        if (stats.total_bytes > 0) {
            stats.used_percent = 100.0 * static_cast<double>(stats.used_bytes) / static_cast<double>(stats.total_bytes);
        }
        disks.push_back(stats);
    }

    return true;
}

bool Collector::readNetworkStats(std::vector<NetworkStat> &network, std::string &error) {
    std::ifstream in("/proc/net/dev");
    if (!in) {
        error = "Cannot open /proc/net/dev";
        return false;
    }

    std::string line;
    std::getline(in, line);
    std::getline(in, line);

    while (std::getline(in, line)) {
        std::istringstream iss(line);
        std::string iface;
        if (!(iss >> iface)) {
            continue;
        }
        if (iface.back() == ':') {
            iface.pop_back();
        }

        uint64_t rx_packets = 0;
        uint64_t rx_errs = 0;
        uint64_t rx_drop = 0;
        uint64_t rx_fifo = 0;
        uint64_t rx_frame = 0;
        uint64_t rx_compressed = 0;
        uint64_t rx_multicast = 0;
        uint64_t tx_packets = 0;
        uint64_t tx_errs = 0;
        uint64_t tx_drop = 0;

        if (!(iss >> stats.rx_bytes >> rx_packets >> rx_errs >> rx_drop >> rx_fifo >> rx_frame >> rx_compressed >> rx_multicast >> stats.tx_bytes >> tx_packets >> tx_errs >> tx_drop)) {
            continue;
        }

        stats.rx_errors = rx_errs;
        stats.tx_errors = tx_errs;
        network.push_back(stats);
    }

    return true;
}

} // namespace sentinel
