#pragma once

#include <cstdint>
#include <string>
#include <vector>

namespace sentinel {

struct CPUStat {
    double total_seconds = 0.0;
    double idle_seconds = 0.0;
    double usage_percent = 0.0;
};

struct MemoryStat {
    uint64_t total_kb = 0;
    uint64_t free_kb = 0;
    uint64_t available_kb = 0;
    uint64_t buffers_kb = 0;
    uint64_t cached_kb = 0;
    double used_percent = 0.0;
};

struct DiskStat {
    std::string mountpoint;
    uint64_t total_bytes = 0;
    uint64_t used_bytes = 0;
    uint64_t avail_bytes = 0;
    double used_percent = 0.0;
};

struct NetworkStat {
    std::string iface;
    uint64_t rx_bytes = 0;
    uint64_t tx_bytes = 0;
    uint64_t rx_errors = 0;
    uint64_t tx_errors = 0;
};

struct SystemMetrics {
    CPUStat cpu;
    MemoryStat memory;
    std::vector<DiskStat> disks;
    std::vector<NetworkStat> network;
    double uptime_seconds = 0.0;
};

class Collector {
public:
    // Collect a full set of system metrics in one pass.
    static bool collect(SystemMetrics &out, std::string &error);

private:
    static bool readCPU(CPUStat &cpu, std::string &error);
    static bool readMemory(MemoryStat &memory, std::string &error);
    static bool readUptime(double &uptime, std::string &error);
    static bool readDiskStats(std::vector<DiskStat> &disks, std::string &error);
    static bool readNetworkStats(std::vector<NetworkStat> &network, std::string &error);
};

} // namespace sentinel
