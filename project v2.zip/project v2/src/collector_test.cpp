#include "collector/collector.h"
#include <iostream>

int main() {
    sentinel::SystemMetrics metrics;
    std::string error;
    if (!sentinel::Collector::collect(metrics, error)) {
        std::cerr << "Collector failed: " << error << std::endl;
        return 1;
    }

    std::cout << "CPU usage: " << metrics.cpu.usage_percent << "%\n";
    std::cout << "Memory used: " << metrics.memory.used_percent << "%\n";
    std::cout << "Uptime: " << metrics.uptime_seconds << " seconds\n";
    std::cout << "Disks: " << metrics.disks.size() << " entries\n";
    std::cout << "Network interfaces: " << metrics.network.size() << " entries\n";
    return 0;
}
