#include "server.h"
#include "collector/collector.h"

#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include <cstring>
#include <iostream>
#include <sstream>

namespace sentinel {

WebServer::WebServer() = default;
WebServer::~WebServer() {
    if (server_fd_ != -1) {
        close(server_fd_);
    }
}

bool WebServer::setupSocket(uint16_t port, std::string &error) {
    server_fd_ = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd_ == -1) {
        error = "Failed to create socket";
        return false;
    }

    int opt = 1;
    if (setsockopt(server_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        error = "Failed to set socket options";
        return false;
    }

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port);

    if (bind(server_fd_, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) < 0) {
        error = "Failed to bind socket to port ";
        error += std::to_string(port);
        return false;
    }

    if (listen(server_fd_, 10) < 0) {
        error = "Failed to listen on socket";
        return false;
    }

    running_ = true;
    return true;
}

bool WebServer::start(uint16_t port, std::string &error) {
    return setupSocket(port, error);
}

void WebServer::run() {
    while (running_) {
        sockaddr_in client_addr{};
        socklen_t client_len = sizeof(client_addr);
        int client_fd = accept(server_fd_, reinterpret_cast<sockaddr *>(&client_addr), &client_len);
        if (client_fd < 0) {
            continue;
        }
        handleClient(client_fd);
        close(client_fd);
    }
}

void WebServer::handleClient(int client_fd) {
    const size_t buffer_size = 4096;
    char buffer[buffer_size];
    ssize_t received = recv(client_fd, buffer, buffer_size - 1, 0);
    if (received <= 0) {
        return;
    }
    buffer[received] = '\0';
    std::string request(buffer);

    std::istringstream request_stream(request);
    std::string method;
    std::string path;
    request_stream >> method >> path;

    std::string response_body;
    std::string content_type = "text/html";
    int status_code = 200;
    std::string status_text = "OK";

    if (method != "GET") {
        status_code = 405;
        status_text = "Method Not Allowed";
        response_body = "<h1>405 Method Not Allowed</h1>";
    } else if (path == "/") {
        response_body = buildIndexPage();
    } else if (path == "/api/metrics") {
        content_type = "application/json";
        response_body = buildMetricsJson();
    } else {
        status_code = 404;
        status_text = "Not Found";
        response_body = "<h1>404 Not Found</h1>";
    }

    std::ostringstream out;
    out << "HTTP/1.1 " << status_code << " " << status_text << "\r\n";
    out << "Content-Type: " << content_type << "; charset=UTF-8\r\n";
    out << "Content-Length: " << response_body.size() << "\r\n";
    out << "Connection: close\r\n";
    out << "\r\n";
    out << response_body;

    std::string response = out.str();
    send(client_fd, response.c_str(), response.size(), 0);
}

std::string WebServer::buildIndexPage() const {
    std::ostringstream html;
    html << "<!DOCTYPE html>\n";
    html << "<html><head><meta charset='utf-8'><title>Sentinel OSS</title></head><body>\n";
    html << "<h1>Sentinel OSS</h1>\n";
    html << "<p>Simple Linux monitoring service. Access <a href='/api/metrics'>/api/metrics</a> for live JSON data.</p>\n";
    html << "</body></html>\n";
    return html.str();
}

std::string WebServer::buildMetricsJson() const {
    Collector collector;
    SystemMetrics metrics;
    std::string error;
    if (!collector.collect(metrics, error)) {
        return "{\"error\": \"" + escapeJson(error) + "\"}";
    }

    std::ostringstream json;
    json << "{";
    json << "\"cpu\": { \"usage_percent\": " << metrics.cpu.usage_percent << " }, ";
    json << "\"memory\": { \"used_percent\": " << metrics.memory.used_percent << " }, ";
    json << "\"uptime_seconds\": " << metrics.uptime_seconds << ", ";
    json << "\"disks\": [";
    for (size_t i = 0; i < metrics.disks.size(); ++i) {
        const auto &d = metrics.disks[i];
        json << "{\"mountpoint\": \"" << escapeJson(d.mountpoint) << "\", \"used_percent\": " << d.used_percent << ", \"total_bytes\": " << d.total_bytes << ", \"used_bytes\": " << d.used_bytes << ", \"avail_bytes\": " << d.avail_bytes << "}";
        if (i + 1 < metrics.disks.size()) {
            json << ", ";
        }
    }
    json << "], ";
    json << "\"network\": [";
    for (size_t i = 0; i < metrics.network.size(); ++i) {
        const auto &n = metrics.network[i];
        json << "{\"iface\": \"" << escapeJson(n.iface) << "\", \"rx_bytes\": " << n.rx_bytes << ", \"tx_bytes\": " << n.tx_bytes << ", \"rx_errors\": " << n.rx_errors << ", \"tx_errors\": " << n.tx_errors << "}";
        if (i + 1 < metrics.network.size()) {
            json << ", ";
        }
    }
    json << "]";
    json << "}";
    return json.str();
}

std::string WebServer::escapeJson(const std::string &value) const {
    std::ostringstream escaped;
    for (char c : value) {
        switch (c) {
            case '\\': escaped << "\\\\"; break;
            case '"': escaped << "\\\""; break;
            case '\b': escaped << "\\b"; break;
            case '\f': escaped << "\\f"; break;
            case '\n': escaped << "\\n"; break;
            case '\r': escaped << "\\r"; break;
            case '\t': escaped << "\\t"; break;
            default:
                if (static_cast<unsigned char>(c) < 0x20) {
                    escaped << "\\u" << std::hex << std::uppercase << (int)c;
                } else {
                    escaped << c;
                }
        }
    }
    return escaped.str();
}

} // namespace sentinel
