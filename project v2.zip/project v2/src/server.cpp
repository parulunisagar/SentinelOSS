#include "server.h"
#include "collector/collector.h"

#include <arpa/inet.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include <algorithm>
#include <cstring>
#include <iostream>
#include <sstream>

namespace sentinel {

WebServer::WebServer() = default;
WebServer::~WebServer() {
    if (server_fd_ != -1) {
        close(server_fd_);
    }
}

bool WebServer::setupSocket(uint16_t port, std::string &error) {
    server_fd_ = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd_ == -1) {
        error = "Failed to create socket";
        return false;
    }

    int opt = 1;
    if (setsockopt(server_fd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        error = "Failed to set socket options";
        return false;
    }

    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = INADDR_ANY;
    addr.sin_port = htons(port);

    if (bind(server_fd_, reinterpret_cast<sockaddr *>(&addr), sizeof(addr)) < 0) {
        error = "Failed to bind socket to port ";
        error += std::to_string(port);
        return false;
    }

    if (listen(server_fd_, 10) < 0) {
        error = "Failed to listen on socket";
        return false;
    }

    running_ = true;
    return true;
}

bool WebServer::start(uint16_t port, std::string &error) {
    return setupSocket(port, error);
}

void WebServer::run() {
    while (running_) {
        sockaddr_in client_addr{};
        socklen_t client_len = sizeof(client_addr);
        int client_fd = accept(server_fd_, reinterpret_cast<sockaddr *>(&client_addr), &client_len);
        if (client_fd < 0) {
            continue;
        }
        handleClient(client_fd);
        close(client_fd);
    }
}

void WebServer::handleClient(int client_fd) {
    const size_t buffer_size = 4096;
    char buffer[buffer_size];
    ssize_t received = recv(client_fd, buffer, buffer_size - 1, 0);
    if (received <= 0) {
        return;
    }
    buffer[received] = '\0';
    std::string request(buffer);

    std::istringstream request_stream(request);
    std::string method;
    std::string path;
    request_stream >> method >> path;

    const auto query_pos = path.find('?');
    if (query_pos != std::string::npos) {
        path = path.substr(0, query_pos);
    }

    std::string response_body;
    std::string content_type = "text/html";
    int status_code = 200;
    std::string status_text = "OK";

    if (method != "GET") {
        status_code = 405;
        status_text = "Method Not Allowed";
        response_body = "<h1>405 Method Not Allowed</h1>";
    } else if (path == "/") {
        response_body = buildIndexPage();
    } else if (path == "/api/metrics") {
        content_type = "application/json";
        response_body = buildMetricsJson();
    } else if (path == "/api/health") {
        content_type = "application/json";
        response_body = buildHealthJson();
    } else if (path == "/api/alerts") {
        content_type = "application/json";
        response_body = buildAlertsJson();
    } else if (path == "/api/system") {
        content_type = "application/json";
        response_body = buildSystemJson();
    } else if (path == "/api/network") {
        content_type = "application/json";
        response_body = buildNetworkJson();
    } else {
        status_code = 404;
        status_text = "Not Found";
        response_body = "<h1>404 Not Found</h1>";
    }

    std::ostringstream out;
    out << "HTTP/1.1 " << status_code << " " << status_text << "\r\n";
    out << "Content-Type: " << content_type << "; charset=UTF-8\r\n";
    out << "Content-Length: " << response_body.size() << "\r\n";
    out << "Connection: close\r\n";
    out << "\r\n";
    out << response_body;

    std::string response = out.str();
    send(client_fd, response.c_str(), response.size(), 0);
}

std::string WebServer::buildIndexPage() const {
    return R"HTML(<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sentinel OSS Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        :root {
            color-scheme: dark;
            font-family: 'Inter', sans-serif;
            background: radial-gradient(circle at top left, #1b2533 0%, #101820 45%, #090c10 100%);
            color: #e8eef7;
        }
        * { box-sizing: border-box; }
        body { margin: 0; min-height: 100vh; }
        .page { width: min(1200px, 100%); margin: 0 auto; padding: 24px; }
        header { display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; gap: 16px; padding-bottom: 16px; }
        .brand { display: flex; align-items: center; gap: 12px; }
        .brand-mark { width: 40px; height: 40px; border-radius: 12px; background: linear-gradient(135deg, #4d9eff, #00ffa8); display: grid; place-items: center; font-weight: 800; color: #080c13; }
        .brand-title h1 { margin: 0; font-size: 1.4rem; letter-spacing: -0.03em; }
        .brand-title p { margin: 4px 0 0; color: #9bb0cc; font-size: 0.95rem; }
        nav { display: flex; flex-wrap: wrap; gap: 12px; }
        nav a { text-decoration: none; color: #9bb0cc; font-weight: 500; transition: color .2s ease; }
        nav a:hover { color: #fff; }
        .hero { display: grid; gap: 16px; margin-top: 16px; }
        .card-grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 16px; margin-top: 18px; }
        .card, .panel { background: rgba(18, 26, 40, 0.82); border: 1px solid rgba(255,255,255,0.08); backdrop-filter: blur(18px); border-radius: 24px; padding: 22px; }
        .card-title { margin: 0 0 12px; color: #a9b7d6; font-size: 0.94rem; letter-spacing: 0.04em; text-transform: uppercase; }
        .metric-value { font-size: 2.1rem; font-weight: 700; margin: 0; }
        .metric-description { margin: 8px 0 0; color: #7c8ba4; font-size: 0.95rem; }
        .status-pill { display: inline-flex; align-items: center; gap: 8px; padding: 10px 14px; border-radius: 999px; font-weight: 700; font-size: 0.92rem; }
        .status-excellent { background: rgba(4, 200, 147, 0.15); color: #9dffda; }
        .status-good { background: rgba(56, 167, 255, 0.15); color: #9ad6ff; }
        .status-warning { background: rgba(255, 181, 0, 0.16); color: #ffdd8d; }
        .status-critical { background: rgba(255, 88, 88, 0.16); color: #ffb2b2; }
        .dashboard-grid { display: grid; grid-template-columns: 1.5fr 1fr; gap: 16px; margin-top: 20px; }
        .charts { display: grid; gap: 16px; }
        .chart-card { padding: 20px; }
        .alerts-panel h2, .panel h2 { margin: 0 0 16px; font-size: 1.05rem; }
        .alerts-list { display: grid; gap: 12px; }
        .alert { border: 1px solid rgba(255,255,255,0.08); padding: 16px; border-radius: 18px; background: rgba(16,24,38,0.8); }
        .alert-title { margin: 0 0 6px; font-weight: 700; }
        .alert-text { margin: 0; color: #c3d0e2; }
        footer { margin: 40px 0 0; padding: 18px 0; color: #7c8ba4; font-size: 0.92rem; border-top: 1px solid rgba(255,255,255,0.08); display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; }
        .footer-links a { color: #7c8ba4; text-decoration: none; }
        .footer-links a:hover { color: #fff; }
        @media (max-width: 900px) {
            .card-grid { grid-template-columns: repeat(2, minmax(0, 1fr)); }
            .dashboard-grid { grid-template-columns: 1fr; }
        }
        @media (max-width: 640px) {
            .hero, header, .card-grid { gap: 12px; }
            .card-grid { grid-template-columns: 1fr; }
            nav { justify-content: flex-start; width: 100%; }
        }
    </style>
</head>
<body>
    <div class="page">
        <header>
            <div class="brand">
                <div class="brand-mark">S</div>
                <div class="brand-title">
                    <h1>Sentinel OSS</h1>
                    <p>Open source Linux monitoring and security dashboard</p>
                </div>
            </div>
            <nav>
                <a href="#overview">Overview</a>
                <a href="#metrics">Metrics</a>
                <a href="#alerts">Alerts</a>
                <a href="#health">Health</a>
            </nav>
        </header>

        <section class="hero" id="overview">
            <div class="card">
                <p class="card-title">Sentinel status</p>
                <div style="display:flex; align-items:center; justify-content:space-between; gap:16px; flex-wrap:wrap;">
                    <div>
                        <p class="metric-value" id="health-score">--</p>
                        <div id="health-status" class="status-pill status-good">Loading</div>
                    </div>
                    <p class="metric-description">Real-time system health, alert detection, and infrastructure monitoring for your Oracle Linux host.</p>
                </div>
            </div>
        </section>

        <div class="card-grid" id="metrics">
            <div class="card">
                <p class="card-title">CPU Usage</p>
                <p class="metric-value" id="cpu-value">--%</p>
                <p class="metric-description">Current processor utilization.</p>
            </div>
            <div class="card">
                <p class="card-title">RAM Usage</p>
                <p class="metric-value" id="memory-value">--%</p>
                <p class="metric-description">System memory consumed.</p>
            </div>
            <div class="card">
                <p class="card-title">Disk Usage</p>
                <p class="metric-value" id="disk-value">--%</p>
                <p class="metric-description">Root filesystem utilization.</p>
            </div>
            <div class="card">
                <p class="card-title">Network RX</p>
                <p class="metric-value" id="rx-value">-- MB</p>
                <p class="metric-description">Received bytes on active interfaces.</p>
            </div>
            <div class="card">
                <p class="card-title">Network TX</p>
                <p class="metric-value" id="tx-value">-- MB</p>
                <p class="metric-description">Transmitted bytes on active interfaces.</p>
            </div>
            <div class="card">
                <p class="card-title">Uptime</p>
                <p class="metric-value" id="uptime-value">--</p>
                <p class="metric-description">Time since the host last booted.</p>
            </div>
        </div>

        <div class="dashboard-grid">
            <div class="charts">
                <div class="panel chart-card">
                    <h2>CPU Usage History</h2>
                    <canvas id="cpuChart"></canvas>
                </div>
                <div class="panel chart-card">
                    <h2>Memory Usage History</h2>
                    <canvas id="ramChart"></canvas>
                </div>
                <div class="panel chart-card">
                    <h2>Network Traffic</h2>
                    <canvas id="networkChart"></canvas>
                </div>
            </div>
            <div class="alerts-panel panel" id="alerts">
                <h2>Active Alerts</h2>
                <div class="alerts-list" id="alerts-list">
                    <div class="alert"><p class="alert-title">Loading alerts...</p></div>
                </div>
            </div>
        </div>

        <footer>
            <div>Sentinel OSS • Open-source Linux monitoring for Oracle Cloud</div>
            <div class="footer-links"><a href="https://github.com/your-org/sentinel-oss">GitHub</a> · <a href="#health">Health checks</a></div>
        </footer>
    </div>

    <script>
        const cpuValues = [];
        const memoryValues = [];
        const rxValues = [];
        const txValues = [];
        const labels = [];

        const cpuCtx = document.getElementById('cpuChart').getContext('2d');
        const ramCtx = document.getElementById('ramChart').getContext('2d');
        const networkCtx = document.getElementById('networkChart').getContext('2d');

        const cpuChart = new Chart(cpuCtx, {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: 'CPU %',
                    data: cpuValues,
                    backgroundColor: 'rgba(77, 158, 255, 0.2)',
                    borderColor: 'rgba(77, 158, 255, 1)',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true,
                }]
            },
            options: { responsive: true, scales: { y: { beginAtZero: true, max: 100 } } }
        });

        const ramChart = new Chart(ramCtx, {
            type: 'line',
            data: {
                labels,
                datasets: [{
                    label: 'RAM %',
                    data: memoryValues,
                    backgroundColor: 'rgba(0, 255, 170, 0.16)',
                    borderColor: 'rgba(0, 255, 170, 0.9)',
                    borderWidth: 2,
                    tension: 0.3,
                    fill: true,
                }]
            },
            options: { responsive: true, scales: { y: { beginAtZero: true, max: 100 } } }
        });

        const networkChart = new Chart(networkCtx, {
            type: 'line',
            data: {
                labels,
                datasets: [
                    {
                        label: 'RX MB',
                        data: rxValues,
                        backgroundColor: 'rgba(255, 198, 78, 0.18)',
                        borderColor: 'rgba(255, 198, 78, 1)',
                        borderWidth: 2,
                        tension: 0.3,
                        fill: true,
                    },
                    {
                        label: 'TX MB',
                        data: txValues,
                        backgroundColor: 'rgba(148, 125, 255, 0.18)',
                        borderColor: 'rgba(148, 125, 255, 1)',
                        borderWidth: 2,
                        tension: 0.3,
                        fill: true,
                    }
                ]
            },
            options: {
                responsive: true,
                scales: { y: { beginAtZero: true } }
            }
        });

        function formatDuration(seconds) {
            const days = Math.floor(seconds / 86400);
            const hours = Math.floor((seconds % 86400) / 3600);
            const minutes = Math.floor((seconds % 3600) / 60);
            return `${days}d ${hours}h ${minutes}m`;
        }

        function updateCard(id, value) {
            const el = document.getElementById(id);
            if (el) el.textContent = value;
        }

        function renderAlerts(alerts) {
            const container = document.getElementById('alerts-list');
            if (!container) return;
            container.innerHTML = '';
            if (!alerts.length) {
                container.innerHTML = '<div class="alert"><p class="alert-title">No active alerts</p><p class="alert-text">All monitored signals are within normal thresholds.</p></div>';
                return;
            }
            alerts.forEach(a => {
                const item = document.createElement('div');
                item.className = 'alert';
                item.innerHTML = `<p class="alert-title">${a.title}</p><p class="alert-text">${a.message}</p>`;
                container.appendChild(item);
            });
        }

        async function refreshDashboard() {
            try {
                const [metricsRes, healthRes, alertsRes] = await Promise.all([
                    fetch('/api/metrics'),
                    fetch('/api/health'),
                    fetch('/api/alerts')
                ]);
                const metrics = await metricsRes.json();
                const health = await healthRes.json();
                const alerts = await alertsRes.json();

                updateCard('cpu-value', `${metrics.cpu.usage_percent.toFixed(1)}%`);
                updateCard('memory-value', `${metrics.memory.used_percent.toFixed(1)}%`);
                updateCard('uptime-value', formatDuration(metrics.uptime_seconds));

                const rootDisk = metrics.disks.find(d => d.mountpoint === '/') || metrics.disks[0] || { used_percent: 0 };
                updateCard('disk-value', `${rootDisk.used_percent.toFixed(1)}%`);

                const rxTotal = metrics.network.reduce((sum, item) => sum + item.rx_bytes, 0) / 1024 / 1024;
                const txTotal = metrics.network.reduce((sum, item) => sum + item.tx_bytes, 0) / 1024 / 1024;
                updateCard('rx-value', `${rxTotal.toFixed(1)} MB`);
                updateCard('tx-value', `${txTotal.toFixed(1)} MB`);

                updateCard('health-score', `${health.health_score}`);
                const pill = document.getElementById('health-status');
                pill.textContent = health.status;
                pill.className = `status-pill status-${health.status.toLowerCase()}`;

                renderAlerts(alerts.alerts || []);

                const nowLabel = new Date().toLocaleTimeString();
                if (labels.length >= 30) {
                    labels.shift(); cpuValues.shift(); memoryValues.shift(); rxValues.shift(); txValues.shift();
                }
                labels.push(nowLabel);
                cpuValues.push(metrics.cpu.usage_percent.toFixed(1));
                memoryValues.push(metrics.memory.used_percent.toFixed(1));
                rxValues.push(rxTotal.toFixed(1));
                txValues.push(txTotal.toFixed(1));

                cpuChart.update();
                ramChart.update();
                networkChart.update();
            } catch (error) {
                console.error('Dashboard refresh failed', error);
            }
        }

        refreshDashboard();
        setInterval(refreshDashboard, 2000);
    </script>
</body>
</html>)HTML";
}

std::string WebServer::buildMetricsJson() const {
    Collector collector;
    SystemMetrics metrics;
    std::string error;
    if (!collector.collect(metrics, error)) {
        return "{\"error\": \"" + escapeJson(error) + "\"}";
    }

    std::ostringstream json;
    json << "{";
    json << "\"cpu\": { \"usage_percent\": " << metrics.cpu.usage_percent << " }, ";
    json << "\"memory\": { \"used_percent\": " << metrics.memory.used_percent << " }, ";
    json << "\"uptime_seconds\": " << metrics.uptime_seconds << ", ";

    json << "\"disks\": [";
    for (size_t i = 0; i < metrics.disks.size(); ++i) {
        const auto &d = metrics.disks[i];
        json << "{\"mountpoint\": \"" << escapeJson(d.mountpoint) << "\", \"used_percent\": " << d.used_percent << ", \"total_bytes\": " << d.total_bytes << ", \"used_bytes\": " << d.used_bytes << ", \"avail_bytes\": " << d.avail_bytes << "}";
        if (i + 1 < metrics.disks.size()) {
            json << ", ";
        }
    }
    json << "], ";

    json << "\"network\": [";
    for (size_t i = 0; i < metrics.network.size(); ++i) {
        const auto &n = metrics.network[i];
        json << "{\"iface\": \"" << escapeJson(n.iface) << "\", \"rx_bytes\": " << n.rx_bytes << ", \"tx_bytes\": " << n.tx_bytes << ", \"rx_errors\": " << n.rx_errors << ", \"tx_errors\": " << n.tx_errors << "}";
        if (i + 1 < metrics.network.size()) {
            json << ", ";
        }
    }
    json << "]";
    json << "}";
    return json.str();
}

std::string WebServer::buildSystemJson() const {
    Collector collector;
    SystemMetrics metrics;
    std::string error;
    if (!collector.collect(metrics, error)) {
        return "{\"error\": \"" + escapeJson(error) + "\"}";
    }

    std::ostringstream json;
    json << "{";
    json << "\"cpu\": { \"usage_percent\": " << metrics.cpu.usage_percent << " }, ";
    json << "\"memory\": { \"used_percent\": " << metrics.memory.used_percent << " }, ";
    json << "\"uptime_seconds\": " << metrics.uptime_seconds << ", ";
    json << "\"disks\": [";
    for (size_t i = 0; i < metrics.disks.size(); ++i) {
        const auto &d = metrics.disks[i];
        json << "{\"mountpoint\": \"" << escapeJson(d.mountpoint) << "\", \"used_percent\": " << d.used_percent << ", \"total_bytes\": " << d.total_bytes << ", \"used_bytes\": " << d.used_bytes << ", \"avail_bytes\": " << d.avail_bytes << "}";
        if (i + 1 < metrics.disks.size()) {
            json << ", ";
        }
    }
    json << "]";
    json << "}";
    return json.str();
}

std::string WebServer::buildNetworkJson() const {
    Collector collector;
    SystemMetrics metrics;
    std::string error;
    if (!collector.collect(metrics, error)) {
        return "{\"error\": \"" + escapeJson(error) + "\"}";
    }

    std::ostringstream json;
    json << "{";
    json << "\"network\": [";
    for (size_t i = 0; i < metrics.network.size(); ++i) {
        const auto &n = metrics.network[i];
        json << "{\"iface\": \"" << escapeJson(n.iface) << "\", \"rx_bytes\": " << n.rx_bytes << ", \"tx_bytes\": " << n.tx_bytes << ", \"rx_errors\": " << n.rx_errors << ", \"tx_errors\": " << n.tx_errors << "}";
        if (i + 1 < metrics.network.size()) {
            json << ", ";
        }
    }
    json << "]";
    json << "}";
    return json.str();
}

std::string WebServer::buildHealthJson() const {
    Collector collector;
    SystemMetrics metrics;
    std::string error;
    if (!collector.collect(metrics, error)) {
        return "{\"health_score\": 0, \"status\": \"Critical\", \"message\": \"" + escapeJson(error) + "\"}";
    }

    const double score = computeHealthScore(metrics);
    const std::string status = healthStatus(score);
    std::ostringstream json;
    json << "{";
    json << "\"health_score\": " << static_cast<int>(score) << ", ";
    json << "\"status\": \"" << status << "\", ";
    json << "\"recommended_action\": \"" << escapeJson(status == "Excellent" ? "System is healthy." : status == "Good" ? "Monitor for potential spikes." : status == "Warning" ? "Investigate trending resources." : "Check usage and reduce load.") << "\"";
    json << "}";
    return json.str();
}

static std::string buildAlertEntry(const std::string &title, const std::string &message) {
    std::ostringstream json;
    json << "{\"title\": \"" << WebServer::escapeJson(title) << "\", \"message\": \"" << WebServer::escapeJson(message) << "\"}";
    return json.str();
}

std::string WebServer::buildAlertsJson() const {
    Collector collector;
    SystemMetrics metrics;
    std::string error;
    if (!collector.collect(metrics, error)) {
        return "{\"alerts\": [" + buildAlertEntry("Service Failure", error) + "]}";
    }

    std::ostringstream json;
    json << "{\"alerts\": [";
    bool first = true;
    if (metrics.cpu.usage_percent > 80.0) {
        if (!first) json << ", ";
        json << buildAlertEntry("High CPU Usage", "CPU usage exceeded 80%.");
        first = false;
    }
    if (metrics.memory.used_percent > 80.0) {
        if (!first) json << ", ";
        json << buildAlertEntry("High RAM Usage", "Memory utilization exceeded 80%.");
        first = false;
    }
    for (const auto &disk : metrics.disks) {
        if (disk.used_percent > 90.0) {
            if (!first) json << ", ";
            json << buildAlertEntry("Low Disk Space", "Low space on " + disk.mountpoint + " (" + std::to_string(static_cast<int>(disk.used_percent)) + "% used). ");
            first = false;
        }
    }
    json << "]}";
    return json.str();
}

std::string WebServer::escapeJson(const std::string &value) {
    std::ostringstream escaped;
    for (char c : value) {
        switch (c) {
            case '\\': escaped << "\\\\"; break;
            case '"': escaped << "\\\""; break;
            case '\b': escaped << "\\b"; break;
            case '\f': escaped << "\\f"; break;
            case '\n': escaped << "\\n"; break;
            case '\r': escaped << "\\r"; break;
            case '\t': escaped << "\\t"; break;
            default:
                if (static_cast<unsigned char>(c) < 0x20) {
                    escaped << "\\u" << std::hex << std::uppercase << (int)c;
                } else {
                    escaped << c;
                }
        }
    }
    return escaped.str();
}

double WebServer::computeHealthScore(const SystemMetrics &metrics) {
    const double cpuPenalty = std::max(0.0, metrics.cpu.usage_percent - 20.0) * 0.6;
    const double memoryPenalty = std::max(0.0, metrics.memory.used_percent - 25.0) * 0.4;
    double diskPenalty = 0.0;
    for (const auto &disk : metrics.disks) {
        diskPenalty += std::max(0.0, disk.used_percent - 70.0) * 0.3;
    }
    const double raw = 100.0 - cpuPenalty - memoryPenalty - diskPenalty;
    return std::max(0.0, std::min(100.0, raw));
}

std::string WebServer::healthStatus(double score) {
    if (score >= 90.0) return "Excellent";
    if (score >= 75.0) return "Good";
    if (score >= 50.0) return "Warning";
    return "Critical";
}

} // namespace sentinel
