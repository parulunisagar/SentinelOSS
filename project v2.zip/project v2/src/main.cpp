#include "server.h"
#include <iostream>

int main() {
    sentinel::WebServer server;
    std::string error;
    const uint16_t port = 8080;
    if (!server.start(port, error)) {
        std::cerr << "Server startup failed: " << error << std::endl;
        return 1;
    }

    std::cout << "Sentinel OSS server listening on port " << port << "\n";
    server.run();
    return 0;
}
