#pragma once

#include <string>
#include <vector>
#include <map>
#include <sqlite3.h>

namespace sentinel {

class DB {
public:
    explicit DB(const std::string &path);
    ~DB();

    // non-copyable
    DB(const DB &) = delete;
    DB &operator=(const DB &) = delete;

    bool isOpen() const noexcept;

    // Execute SQL (no results expected)
    bool execute(const std::string &sql, std::string *err = nullptr);

    // Execute SQL and return rows; each row is map col->value
    bool query(const std::string &sql, std::vector<std::map<std::string, std::string>> &out, std::string *err = nullptr);

    // Execute SQL script from file (use for migrations)
    bool executeScriptFromFile(const std::string &filePath, std::string *err = nullptr);

private:
    sqlite3 *db_ = nullptr;
};

} // namespace sentinel
