#include "db/db.h"

#include <stdexcept>
#include <fstream>
#include <sstream>
#include <utility>

namespace sentinel {

DB::DB(const std::string &path) {
    int rc = sqlite3_open_v2(path.c_str(), &db_, SQLITE_OPEN_READWRITE | SQLITE_OPEN_CREATE | SQLITE_OPEN_FULLMUTEX, nullptr);
    if (rc != SQLITE_OK) {
        db_ = nullptr;
        throw std::runtime_error(std::string("Failed to open sqlite db: ") + sqlite3_errstr(rc));
    }
    // Set busy timeout so concurrent readers/writers wait briefly instead of failing.
    sqlite3_busy_timeout(db_, 5000);

    // Enable foreign keys. This helps ensure referential integrity in the schema.
    char *errmsg = nullptr;
    sqlite3_exec(db_, "PRAGMA foreign_keys = ON;", nullptr, nullptr, &errmsg);
    if (errmsg) { sqlite3_free(errmsg); errmsg = nullptr; }

    // Use write-ahead logging for better concurrency and crash recovery.
    sqlite3_exec(db_, "PRAGMA journal_mode = WAL;", nullptr, nullptr, &errmsg);
    if (errmsg) { sqlite3_free(errmsg); errmsg = nullptr; }
}

DB::~DB() {
    if (db_) {
        sqlite3_close(db_);
        db_ = nullptr;
    }
}

bool DB::isOpen() const noexcept {
    return db_ != nullptr;
}

bool DB::execute(const std::string &sql, std::string *err) {
    if (!db_) {
        if (err) *err = "DB not open";
        return false;
    }
    char *errmsg = nullptr;
    int rc = sqlite3_exec(db_, sql.c_str(), nullptr, nullptr, &errmsg);
    if (rc != SQLITE_OK) {
        if (err) *err = errmsg ? errmsg : sqlite3_errstr(rc);
        if (errmsg) sqlite3_free(errmsg);
        return false;
    }
    return true;
}

struct RowCallbackCtx {
    std::vector<std::map<std::string, std::string>> *out;
};

static int rowCallback(void *p, int argc, char **argv, char **azColName) {
    RowCallbackCtx *ctx = static_cast<RowCallbackCtx *>(p);
    std::map<std::string, std::string> row;
    for (int i = 0; i < argc; ++i) {
        // Convert column values to text. This simple wrapper is designed for learning,
        // not for binary blobs or huge dataset performance.
        std::string key = azColName[i] ? azColName[i] : "";
        std::string val = argv[i] ? argv[i] : "";
        row.emplace(key, val);
    }
    ctx->out->push_back(std::move(row));
    return 0;
}

bool DB::query(const std::string &sql, std::vector<std::map<std::string, std::string>> &out, std::string *err) {
    if (!db_) {
        if (err) *err = "DB not open";
        return false;
    }
    RowCallbackCtx ctx{&out};
    char *errmsg = nullptr;
    int rc = sqlite3_exec(db_, sql.c_str(), rowCallback, &ctx, &errmsg);
    if (rc != SQLITE_OK) {
        if (err) *err = errmsg ? errmsg : sqlite3_errstr(rc);
        if (errmsg) sqlite3_free(errmsg);
        return false;
    }
    return true;
}

bool DB::executeScriptFromFile(const std::string &filePath, std::string *err) {
    std::ifstream in(filePath, std::ios::in);
    if (!in) {
        if (err) *err = "Failed to open script file";
        return false;
    }
    std::ostringstream ss;
    ss << in.rdbuf();
    std::string script = ss.str();
    return execute(script, err);
}

} // namespace sentinel
