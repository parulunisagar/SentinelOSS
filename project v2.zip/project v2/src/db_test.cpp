#include <iostream>
#include "db/db.h"

int main() {
    try {
        sentinel::DB db(":memory:");
        if (!db.isOpen()) {
            std::cerr << "DB failed to open" << std::endl;
            return 1;
        }
        std::string err;
        bool ok = db.execute("CREATE TABLE test (id INTEGER PRIMARY KEY, name TEXT);", &err);
        if (!ok) {
            std::cerr << "Execute error: " << err << std::endl;
            return 2;
        }
        ok = db.execute("INSERT INTO test (name) VALUES ('alice'),('bob');", &err);
        if (!ok) {
            std::cerr << "Insert error: " << err << std::endl;
            return 3;
        }
        std::vector<std::map<std::string,std::string>> rows;
        ok = db.query("SELECT id, name FROM test ORDER BY id;", rows, &err);
        if (!ok) {
            std::cerr << "Query error: " << err << std::endl;
            return 4;
        }
        for (auto &r : rows) {
            std::cout << "row: id=" << r.at("id") << " name=" << r.at("name") << std::endl;
        }
    } catch (const std::exception &ex) {
        std::cerr << "Exception: " << ex.what() << std::endl;
        return 10;
    }
    return 0;
}
