#pragma once

#include <cstdint>
#include <string>

namespace sentinel {

class WebServer {
public:
    WebServer();
    ~WebServer();

    // Start the server on the given port. Returns true on success.
    bool start(uint16_t port, std::string &error);

    // Run the accept loop until the process exits.
    void run();

private:
    int server_fd_ = -1;
    bool running_ = false;

    bool setupSocket(uint16_t port, std::string &error);
    void handleClient(int client_fd);
    std::string buildIndexPage() const;
    std::string buildMetricsJson() const;
    std::string buildHealthJson() const;
    std::string buildAlertsJson() const;
    std::string buildSystemJson() const;
    std::string buildNetworkJson() const;
    static std::string escapeJson(const std::string &value);
    static double computeHealthScore(const SystemMetrics &metrics);
    static std::string healthStatus(double score);
    static std::string buildAlerts(const SystemMetrics &metrics);
};

} // namespace sentinel
