# Contributing to Sentinel OSS

Thank you for contributing to Sentinel OSS. This project is designed to be simple, readable, and extendable.

## How to contribute

- Open issues for bugs, enhancement requests, or documentation improvements.
- Fork the repository and submit a pull request with a clear summary.
- Keep changes small and focused on one feature or fix.
- Follow the existing C++ style and document new APIs.

## Development workflow

1. Fork the repository.
2. Clone your fork.
3. Build the project locally using `cmake`.
4. Run the service and verify the dashboard.
5. Submit a pull request with test steps.

## Coding standards

- Maintain C++17 compatibility.
- Keep deployment instructions Oracle Linux 9 compatible.
- Preserve existing API compatibility unless a breaking change is explicitly documented.

## Reporting issues

- Provide reproduction steps.
- Include relevant logs and endpoint responses.
- If possible, provide suggested fixes.
