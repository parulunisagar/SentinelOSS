# Security Policy

Sentinel OSS takes security seriously. This document describes how to report vulnerabilities and the project security process.

## Reporting a vulnerability

If you discover a security issue, please open an issue with the label `security` or contact the maintainers privately if available.

Include:

- A clear description of the vulnerability.
- The affected endpoint or feature.
- Steps to reproduce the issue.
- Any proof-of-concept details.

## Response process

- Security reports are reviewed promptly.
- If the issue is confirmed, a fix is prioritized.
- Public disclosure is coordinated according to best practices.

## Supported release model

Sentinel OSS is released as source code. Users are encouraged to review code before deployment.
